package com.blueocn.mail.sender.entity;

import java.io.Serializable;
import java.util.Locale;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SendEMail implements Serializable {
    private static final long   serialVersionUID = -6181855270173839618L;

    private String              title;
    private String              to;
    private String              from;
    private Map<String, Object> model;
    private String              templateName;
    private String              content;
    private Locale              locale;
}
