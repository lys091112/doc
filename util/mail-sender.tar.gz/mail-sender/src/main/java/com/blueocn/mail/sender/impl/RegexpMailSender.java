package com.blueocn.mail.sender.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.regex.Pattern;

import com.blueocn.mail.sender.MailSender;
import com.blueocn.mail.sender.MailSenderFactory;
import com.blueocn.mail.sender.entity.SendEMail;
import com.blueocn.mail.sender.ex.NotFoundException;

/**
 * 提供对邮箱进行过滤的发送端实现
 * 
 * @author zhangjian
 *
 */
public class RegexpMailSender implements MailSender {

    private List<Entry<Pattern, MailSender>> roleList = new ArrayList<Entry<Pattern, MailSender>>();

    public void init(Properties config, MailSenderFactory factory) throws NotFoundException {
        List<Object> regexps = (List<Object>) config.get("regexps");

        for (Object object : regexps) {
            if (object instanceof Properties) {
                Properties conf = (Properties) object;

                String ref = conf.getProperty("ref");
                String regexp = conf.getProperty("regexp");

                if (regexp != null && !regexp.trim().isEmpty()) {
                    final Pattern pattern = Pattern.compile(regexp);
                    final MailSender refSender = factory.getOrCreate(ref);;
                    roleList.add(new Entry<Pattern, MailSender>() {

                        public MailSender setValue(MailSender value) {
                            return null;
                        }

                        public MailSender getValue() {
                            return refSender;
                        }

                        public Pattern getKey() {
                            return pattern;
                        }
                    });
                    continue;
                }
            }
            throw new NotFoundException("没有查找到指定的正则表达式,{" + object + "}");
        }
    }

    public boolean send(SendEMail mail) {
        for (Entry<Pattern, MailSender> entry : roleList) {
            Pattern pattern = entry.getKey();
            if (pattern != null) {
                if (pattern.matcher(mail.getTo()).matches()) {
                    return entry.getValue().send(mail);
                }
            }
        }
        return false;
    }

}
