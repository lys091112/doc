package com.blueocn.mail.sender;

import java.util.Properties;

import com.blueocn.mail.sender.entity.SendEMail;
import com.blueocn.mail.sender.ex.NotFoundException;

public interface MailSender {

    public void init(Properties config, MailSenderFactory factory) throws NotFoundException;

    public boolean send(SendEMail mail);
}
