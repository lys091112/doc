package com.blueocn.mail.sender.impl;

import java.util.Properties;

import com.blueocn.mail.sender.MailSender;
import com.blueocn.mail.sender.MailSenderFactory;
import com.blueocn.mail.sender.entity.SendEMail;
import com.blueocn.mail.sender.ex.NotFoundException;

/**
 * 带有错误处理的邮件发送器
 * 
 * @author zhangjian
 *
 */
public class ErrorMailSender implements MailSender {

    private MailSender defaultSender;
    private MailSender errorSender;

    public void init(Properties config, MailSenderFactory factory) throws NotFoundException {
        String defaultSenderRef = config.getProperty("default-ref");
        String errorSenderRef = config.getProperty("error-ref");
        this.defaultSender = factory.getOrCreate(defaultSenderRef);
        this.errorSender = factory.getOrCreate(errorSenderRef);
    }

    public boolean send(SendEMail mail) {
        if (!defaultSender.send(mail)) {
            return errorSender.send(mail);
        }
        return true;
    }

}
