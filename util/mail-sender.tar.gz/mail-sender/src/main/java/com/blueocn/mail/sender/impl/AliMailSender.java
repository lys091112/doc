package com.blueocn.mail.sender.impl;


import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.blueocn.mail.sender.MailSender;
import com.blueocn.mail.sender.MailSenderFactory;
import com.blueocn.mail.sender.entity.SendEMail;


/**
 * 阿里云邮件发送实现
 * 
 * @author zhangjian
 *
 */
public class AliMailSender implements MailSender {

    private static final Logger logger = LoggerFactory.getLogger(MailSender.class);
    private static final Logger log    = LoggerFactory.getLogger(AliMailSender.class);

    // 阿里云服务Host
    private String              aliHost;
    // 阿里云服务端口
    private int                 aliPort;
    // 邮件发件人账号
    private String              sendUser;
    // 邮件发件人密码
    private String              sendPassword;

    public void init(Properties config, MailSenderFactory factory) {
        aliHost = String.valueOf(config.getProperty("alidm.smtp.host", "smtpdm.aliyun.com"));
        aliPort = Integer.valueOf(config.getProperty("alidm.smtp.port"));
        sendUser = String.valueOf(config.getProperty("alidm.mail.user", "noreply@notice.oneapm.com"));
        sendPassword = String.valueOf(config.getProperty("alidm.mail.password"));
    }

    public boolean send(SendEMail mail) {
        try {
            final Properties props = new Properties();
            // 表示SMTP发送邮件，需要进行身份验证
            props.put("mail.smtp.auth", String.valueOf(Boolean.TRUE));
            props.put("mail.smtp.host", aliHost);
            props.put("mail.smtp.port", aliPort);
            props.put("mail.user", sendUser);
            props.put("mail.password", sendPassword);

            // 构建授权信息，用于进行SMTP进行身份验证
            Authenticator authenticator = new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    // 用户名、密码
                    String userName = props.getProperty("mail.user");
                    String password = props.getProperty("mail.password");

                    return new PasswordAuthentication(userName, password);
                }
            };
            // 使用环境属性和授权信息，创建邮件会话
            Session mailSession = Session.getInstance(props, authenticator);
            // 创建邮件消息
            MimeMessage message = new MimeMessage(mailSession);
            // 设置发件人
            InternetAddress form = new InternetAddress(props.getProperty("mail.user"));
            message.setFrom(form);

            // 设置收件人
            message.setRecipients(MimeMessage.RecipientType.TO, new InternetAddress[] {new InternetAddress(mail.getTo())});
            message.setSubject(mail.getTitle());
            message.setContent(mail.getContent(), "text/html;charset=UTF-8");

            // 发送邮件
            Transport.send(message);

            if (log.isDebugEnabled()) {
                log.debug("发送邮件成功" + mail.getTo());
            }
        } catch (Exception e) {
            if (logger.isErrorEnabled()) {
                // 将发送失败的邮件的关键信息保存到日志中,方便补发
                logger.error(String.format("邮件发送失败:|%s|", JSON.toJSONString(mail)));
            }
            if (log.isErrorEnabled()) {
                logger.error("邮件发送失败", e);
            }
            return false;
        }
        return true;
    }

}
