package com.blueocn.mail.sender.ex;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class NotFoundException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public NotFoundException(String msg) {
        super(msg);
    }

    public NotFoundException(Throwable e) {

    }

    public NotFoundException(String msg, Throwable e) {
        super(msg, e);
    }

}
