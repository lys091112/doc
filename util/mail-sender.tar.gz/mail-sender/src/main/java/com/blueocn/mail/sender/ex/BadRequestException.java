package com.blueocn.mail.sender.ex;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class BadRequestException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public BadRequestException(String msg) {
        super(msg);
    }

    public BadRequestException(Throwable e) {
        super(e);
    }

    public BadRequestException(String msg, Throwable e) {
        super(msg, e);
    }
}
