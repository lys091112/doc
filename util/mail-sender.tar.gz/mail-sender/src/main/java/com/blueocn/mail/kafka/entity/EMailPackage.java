package com.blueocn.mail.kafka.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.blueocn.mail.sender.entity.SendEMail;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EMailPackage {
    private static final Iterator<SendEMail> emptyIt = new ArrayList<SendEMail>().iterator();
    private String                           title;
    private List<String>                     to;
    private String                           from;
    private Map<String, Object>              model;
    private String                           templateName;
    private String                           content;
    private Locale                           locale;


    public Iterator<SendEMail> itEMail() {
        if (getTo() != null) {
            List<SendEMail> list = new ArrayList<SendEMail>();
            for (String toAddress : getTo()) {
                Map<String, Object> model = new HashMap<String, Object>();
                if (getModel() != null) {
                    model.putAll(getModel());
                }
                list.add(SendEMail.builder().title(title).from(from).to(toAddress).model(model).templateName(templateName).content(content).locale(locale).build());
            }
            return list.iterator();
        } else {
            return emptyIt;
        }
    }
}
