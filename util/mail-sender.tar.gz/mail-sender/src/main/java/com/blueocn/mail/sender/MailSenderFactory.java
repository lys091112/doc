package com.blueocn.mail.sender;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.blueocn.mail.misc.PropertiesUtils;
import com.blueocn.mail.sender.ex.NotFoundException;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MailSenderFactory {

    private final JSONObject              jsonConfig;

    private final Map<String, MailSender> mailSender = new ConcurrentHashMap<String, MailSender>();



    public MailSender getDefault() throws NotFoundException {
        String defaultName = jsonConfig.getString("default");
        if (defaultName == null || defaultName.trim().isEmpty()) {
            throw new NotFoundException("缺少default配置");
        }
        return getOrCreate(defaultName);
    }

    public MailSender getOrCreate(String name) throws NotFoundException {
        if (!mailSender.containsKey(name)) {
            // 包含递归操作,先创建对象,在初始化,防止死循环
            JSONObject jsonConfig = findJsonConfig(name);

            MailSender sender = create(name, jsonConfig);
            mailSender.put(name, sender);

            sender.init(PropertiesUtils.json2Properties(null, jsonConfig.getJSONObject("configure")), this);
        }
        return mailSender.get(name);
    }

    private MailSender create(String name, JSONObject senderConfig) throws NotFoundException {
        try {
            String className = senderConfig.getString("class");
            @SuppressWarnings("unchecked")
            Class<? extends MailSender> clazz = (Class<? extends MailSender>) Class.forName(className);
            return clazz.newInstance();
        } catch (Exception e) {
            throw new NotFoundException("加载\"" + name + "\"MailSender失败,找不到指定的Class", e);
        }
    }

    private JSONObject findJsonConfig(String name) throws NotFoundException {
        JSONArray jsonArray = jsonConfig.getJSONArray("senders");
        if (jsonArray != null) {
            for (int i = 0; i < jsonArray.size(); i++) {
                JSONObject senderConfig = jsonArray.getJSONObject(i);
                String senderName = senderConfig.getString("name");
                if (name.equals(senderName)) {
                    return senderConfig;
                }
            }
        }
        throw new NotFoundException("没有找到\"" + name + "\"MailSender,请检查配置");
    }
}
