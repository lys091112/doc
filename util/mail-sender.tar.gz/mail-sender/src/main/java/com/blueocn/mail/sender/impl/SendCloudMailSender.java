package com.blueocn.mail.sender.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.blueocn.mail.sender.MailSender;
import com.blueocn.mail.sender.MailSenderFactory;
import com.blueocn.mail.sender.entity.SendEMail;
import com.blueocn.mail.sender.ex.BadRequestException;
import com.blueocn.mail.sender.ex.NotFoundException;
import org.apache.http.HttpResponse;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.config.SocketConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

/**
 * 提供sendCloud的实现
 * 
 * @author zhangjian
 *
 */
public class SendCloudMailSender implements MailSender {
    private static final Logger     logger = LoggerFactory.getLogger(MailSender.class);
    private static final Logger     log    = LoggerFactory.getLogger(SendCloudMailSender.class);

    private final CloseableHttpClient client = HttpClientBuilder.create()
            .setConnectionTimeToLive(3000, TimeUnit.MILLISECONDS)
            .setConnectionManager(new PoolingHttpClientConnectionManager())
            .setDefaultSocketConfig(SocketConfig.custom().setSoTimeout(3000).build())
            .build();

    private String                  apiUser;
    private String                  apiKey;
    private String                  mailUser;



    public void init(Properties config, MailSenderFactory factory) throws NotFoundException {
        apiUser = config.getProperty("sendCloud.api.user");
        apiKey = config.getProperty("sendCloud.api.key");
        mailUser = config.getProperty("sendCloud.api.mail");
    }

    public boolean send(SendEMail mail) {

        try {
            List<BasicNameValuePair> nvps = new ArrayList<BasicNameValuePair>();
            nvps.add(new BasicNameValuePair("api_user", apiUser));
            nvps.add(new BasicNameValuePair("api_key", apiKey));
            nvps.add(new BasicNameValuePair("from", mailUser));
            nvps.add(new BasicNameValuePair("to", mail.getTo()));
            nvps.add(new BasicNameValuePair("subject", mail.getTitle()));
            nvps.add(new BasicNameValuePair("html", mail.getContent()));
            nvps.add(new BasicNameValuePair("fromName", "OneAPM"));

            HttpUriRequest request = RequestBuilder.post("http://sendcloud.sohu.com/webapi/mail.send.json")// .addHeader("Content-Type",
                                                                                                           // "application/json;charset=UTF-8")
                    .setEntity(new UrlEncodedFormEntity(nvps, "UTF-8")).build();

            HttpResponse response = client.execute(request);

            if (response.getStatusLine().getStatusCode() == 200) {
                JSONObject result = JSONObject.parseObject(EntityUtils.toString(response.getEntity()));
                if ("success".equalsIgnoreCase(result.getString("message"))) {
                    if (log.isDebugEnabled()) {
                        log.debug("发送邮件成功" + mail.getTo());
                    }
                    return true;
                }
                throw new BadRequestException("sendCloud请求失败,错误信息:" + result);
            }

            throw new BadRequestException("sendCloud请求失败,http返回状态码:" + response.getStatusLine().getStatusCode());
        } catch (BadRequestException e) {
            if (logger.isErrorEnabled()) {
                // 将发送失败的邮件的关键信息保存到日志中,方便补发
                logger.error(String.format("邮件发送失败:|%s|", JSON.toJSONString(mail)));
            }
            if (log.isErrorEnabled()) {
                log.error("邮件发送失败", e);
            }
        } catch (Throwable e) {
            if (logger.isErrorEnabled()) {
                // 将发送失败的邮件的关键信息保存到日志中,方便补发
                logger.error(String.format("邮件发送失败:|%s|", JSON.toJSONString(mail)));
            }
            if (log.isErrorEnabled()) {
                log.error("邮件发送失败", e);
            }
        }
        return false;
    }

}
