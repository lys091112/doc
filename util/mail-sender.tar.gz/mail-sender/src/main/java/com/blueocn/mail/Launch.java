package com.blueocn.mail;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import com.alibaba.fastjson.JSONObject;
import com.blueocn.mail.kafka.KafkaConsumer;
import com.blueocn.mail.misc.PropertiesUtils;
import com.blueocn.mail.sender.MailSenderFactory;
import com.blueocn.mail.sender.ex.NotFoundException;

public class Launch {
    public static void main(String[] args) throws FileNotFoundException, IOException, NotFoundException {
        // 读取配置文件
        if (args.length == 0) {
            throw new RuntimeException("缺少参数,应传入配置文件路径参数");
        }
        StringBuilder builder = new StringBuilder();
        @SuppressWarnings("resource")
        BufferedReader reader = new BufferedReader(new FileReader(args[0]));

        String line = null;
        while ((line = reader.readLine()) != null) {
            builder.append(line);
        }

        JSONObject config = JSONObject.parseObject(builder.toString());
        MailSenderFactory factory = new MailSenderFactory(config);

        KafkaConsumer consumer = new KafkaConsumer(factory.getDefault(), PropertiesUtils.json2Properties(null, config));
        consumer.start();
    }
}
